"""Inspect local data and Ray's CPU worker import, without requesting an accelerator."""
import importlib.metadata
import shutil
import sys
from pathlib import Path

repo, data, model = (Path(x).resolve() for x in sys.argv[1:])
sys.path.insert(0, str(repo / "automated"))

import ray
import torch
import verl
from experiment import describe_datasets
from verl.workers.actor.routed_actor import RoutedPPOActor

expected = repo / "verl/verl/__init__.py"
print("python", sys.executable)
print("driver verl", verl.__file__, verl.__version__, "actor", RoutedPPOActor.__name__)
if Path(verl.__file__).resolve() != expected:
    raise SystemExit(f"Driver must import {expected}")
for package in ("ray", "torch", "vllm", "peft", "transformers", "accelerate"):
    try:
        print(package, importlib.metadata.version(package))
    except importlib.metadata.PackageNotFoundError:
        print(package, "no distribution metadata")
print("accelerate executable (C)", shutil.which("accelerate"))
print("model", model)
if not (model / "config.json").is_file() or not any(
    p.is_file() for pattern in ("*.safetensors", "*.bin") for p in model.glob(pattern)
):
    raise SystemExit("MODEL_DIR must contain config.json and local model weights")
roles = describe_datasets(
    ("webinstruct_math80", data / "webinstruct_math80/train.parquet"),
    ("amc22_ref16", data / "amc22_ref16/train.jsonl"),
    ("amc23", data / "amc23/train.parquet"),
)
for role, description in roles.items():
    print(role, description["rows"], description["sha256"])
print("torch.cuda device count", torch.cuda.device_count())
ray.init(address="local", num_cpus=1, include_dashboard=False)
try:
    @ray.remote(num_cpus=1, num_gpus=0)
    def origin():
        import verl
        from verl.workers.actor.routed_actor import RoutedPPOActor
        return verl.__file__, verl.__version__, RoutedPPOActor.__name__
    location, version, actor = ray.get(origin.remote(), timeout=90)
    print("Ray worker verl", location, version, "actor", actor)
    if Path(location).resolve() != expected:
        raise SystemExit(f"Ray worker must import {expected}")
    devices = ray.cluster_resources().get("GPU", 0)
    print("Ray GPU resources", devices)
    if devices < 4 or torch.cuda.device_count() < 4:
        raise SystemExit("Import checks passed. Four CUDA-compatible devices must be visible to both torch and Ray for B/C.")
finally:
    ray.shutdown()
