#!/usr/bin/env bash
set -euo pipefail

kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd -- "${GA_REPO:-/ossfs/workspace/GradAlign}" && pwd)
python_bin=${PYTHON_BIN:-python}
model=${MODEL_DIR:-/ossfs/workspace/models/Qwen/qwen2.5-math-1.5b-instruct}
out=${OUT:-/ossfs/workspace/gradalign-ppu-toy-results}
mode=${1:-help}
export GRADALIGN_DATA_ROOT=${GRADALIGN_DATA_ROOT:-"$kit/data"}
export PYTHONPATH="$repo/verl${PYTHONPATH:+:$PYTHONPATH}"
export HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 TRANSFORMERS_OFFLINE=1
export PYTHONUNBUFFERED=1
cd -- "$repo"
case "$mode" in
  help|-h|--help)
    echo "Usage: bash run-toy.sh {select|check|b|oracle|c}"
    echo "Set GA_REPO, MODEL_DIR and OUT to absolute paths. Select four idle cards before GPU modes."
    exit 0 ;;
  select|check|b|oracle|c) ;;
  *) echo "Unknown mode: $mode" >&2; exit 2 ;;
esac
mkdir -p -- "$out"
out=$(cd -- "$out" && pwd)

run() {
  "$@" 2>&1 | tee -a "$out/$mode.log"
}

if [[ $mode == select ]]; then
  run "$python_bin" automated/select_data.py --mode rand_in_chunk --dataset webinstruct_math80 \
    --model toy --candidate_dir "$GRADALIGN_DATA_ROOT/webinstruct_math80" \
    --min_problems 1 --max_problems 8 --n 2 --seed 42 --output_dir "$out/selector"
  exit 0
fi

if [[ $mode == check ]]; then
  run "$python_bin" "$kit/check-imports.py" "$repo" "$GRADALIGN_DATA_ROOT" "$model"
  exit 0
fi

if [[ ! -f "$model/config.json" ]]; then
  echo "Point MODEL_DIR to the local Qwen model snapshot containing config.json." >&2
  exit 2
fi
if [[ $mode == oracle || $mode == c ]]; then
  if ! grep -q -- '--oracle_backend' "$repo/automated/dynamic_selection.py"; then
    echo "Apply the matching native-oracle.patch to this copy before running $mode. See README.md." >&2
    exit 2
  fi
fi
if [[ $mode == oracle ]]; then
  run "$python_bin" automated/run_inference_local.py --oracle_backend native_vllm --model qwen2.5-math-1.5b-instruct \
    --resp_dataset webinstruct_math80 --model_path "$model" \
    --prompts_file "$GRADALIGN_DATA_ROOT/webinstruct_math80/train.jsonl" --output_dir "$out/oracle" \
    --n_samples 4 --max_problems 8 --max_tokens 512 --max_model_len 1536 \
    --tensor_parallel_size "${TP:-4}" --pipeline_parallel_size 1 --batch_size 8 --concurrency 1
  exit 0
fi

# A fresh local Ray instance inherits this process's repository and device visibility.
# V0 is the synchronous veRL interface used for paired-LoRA loading.
export RAY_ADDRESS=local VLLM_USE_V1=0
export TENSORBOARD_DIR="$out/tensorboard/$mode"
recipe=graft_b_all
extra=()
if [[ $mode == c ]]; then
  recipe=graft_c_route
  extra+=(--oracle_backend native_vllm --concurrency 1 --tensor_parallel_size "${TP:-4}")
fi
run "$python_bin" automated/dynamic_selection.py --config "configs/$recipe.yaml" \
  --prefix "ppu_${mode}_toy_s42" --model_path "$model" --ckpt_root "$out/runs" \
  --chunk_size 8 --k 1 --num_selections 1 --iters_per_select 1 \
  --train_batch_size 4 --ppo_mini_batch_size 4 --ppo_micro_batch_size_per_gpu 1 \
  --rollout_n 4 --rollout_val_n 1 --n_samples_train 4 --n_samples_val 4 \
  --max_tokens 512 --max_model_len 1536 --test_freq 1 --save_freq 1 \
  --train_infer_batch_size 8 --val_infer_batch_size 8 \
  --rollout_tp "${TP:-4}" --analysis_gpus 4 --allocated_gpus 4 --n_gpus_per_node 4 "${extra[@]}"
