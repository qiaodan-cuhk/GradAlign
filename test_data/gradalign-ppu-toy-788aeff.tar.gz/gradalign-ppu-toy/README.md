# GradAlign 四卡离线连通性试验

适用于 `feat/graft-oracle-routing` 提交 `788aeff4a3ba482250c7b3c1419fdafd94fd073d`。模型使用容器已有的 Qwen2.5-Math-1.5B-Instruct。本包提供数据、启动脚本、CPU 回归测试和一个可选 Oracle 补丁。运行位置由 `GA_REPO`、`MODEL_DIR`、`OUT` 三个绝对路径决定。

## 在容器中启动

在准备存放工具包的位置解压，再到包目录核对文件。下例保存到已有的持久卷。先按公司的设备分配方式设置好本作业的四张空闲卡，启动脚本会继承现有设备可见性。下列命令均在同一个 shell 中执行。

```bash
tar -xzf gradalign-ppu-toy-788aeff.tar.gz
cd gradalign-ppu-toy
sha256sum -c SHA256SUMS
export KIT="$PWD"
export GA_REPO=/ossfs/workspace/GradAlign
export MODEL_DIR=/ossfs/workspace/models/Qwen/qwen2.5-math-1.5b-instruct
export OUT=/ossfs/workspace/results/gradalign-ppu-toy-01
bash "$KIT/run-toy.sh" select
bash "$KIT/run-toy.sh" check
```

`select` 运行仓库原有 CPU 随机选择器，从数据文件的前 8 题抽 2 题。`check` 校验数据行数、留出集重叠、模型路径、torch 和 Ray 可见的卡数，并在driver 进程和一个本地 Ray CPU worker 上实际导入仓库 veRL 与 RoutedPPOActor。脚本为这次检查新建本地 Ray，结束时关闭它。若任一导入、路径或卡数检查失败，先查看 `$OUT/check.log`。可以用 `PYTHON_BIN` 指定已有公司环境的解释器，C 还会从当前 PATH 调用 `accelerate`，两者应来自同一环境。若已有自定义 `GRADALIGN_DATA_ROOT`，将它显式设为 `$KIT/data` 可使用包内数据。

四卡空闲且检查通过后，原分支可直接做 B。它走原版 GRPO 的更新逻辑和配对 LoRA，足以检验同步 rollout、FSDP、优化器、评测及保存。

```bash
bash "$KIT/run-toy.sh" b
```

公司 Ray 2.43 上，A/C 的原 Oracle 入口需要 Ray Data LLM 2.44.1 或更新版本。仅在要使用本地原生 vLLM Oracle 的仓库副本上应用补丁。先检查补丁适配性。若检查失败，核对该副本版本和本地改动。已经成功应用的补丁只需保留一份。

```bash
cd "$GA_REPO"
git apply --check "$KIT/native-oracle.patch" && git apply "$KIT/native-oracle.patch"
bash "$KIT/run-toy.sh" oracle
bash "$KIT/run-toy.sh" c
```

`oracle` 单独测试本地 vLLM、Qwen 聊天模板、数学判分、题号和排序，输入为训练文件前 8 题。`c` 由主循环重新读取 seed 42 分出的第一个 8 题 chunk，再给 AMC22 参考题采样。请分别运行并检查每条命令的退出状态。工作流只给子进程设置 PYTHONPATH、Hugging Face 离线开关和实验环境变量。B/C 使用本地 Ray 和同步 vLLM V0。默认一个 TP=4 的 rollout 引擎。如果之前验证的是每卡一个引擎，可根据实际部署设置 `TP=1`；独立 native Oracle 仍使用一个引擎。正式组间比较应使用一致的并行参数。

## 规模与结果

| 模式 | 一次运行的工作量 | 成功后查看 |
| --- | --- | --- |
| select | 前 8 题按 seed 42 抽 2 题 | `$OUT/selector/train.parquet` |
| oracle | 前 8 题 × 每题 4 个回答 | `$OUT/oracle/responses_sorted.json` 中 8 个原始题号，每题 sample_id 0–3 |
| b | 首个 chunk 的 8 题入选，1 个更新步抽 4 题，每题 4 个新回答 | 训练目录的 `heldout_metrics.jsonl`、`global_step_1/merged/full/graft_state.txt` |
| c | 相同 8 题，另做候选 8×4 和参考 16×4 的 Oracle rollout，4 个分析进程。1 次更新的批量与 B 相同 | 训练目录的 `selected/iter_0_sim_route_8/routes.json`、`heldout_metrics.jsonl` 和 `global_step_1/merged/{full,retain_only}/graft_state.txt` |

训练目录在 `$OUT/runs/<实验名>/` 下，B/C 用不同前缀。每次运行将控制台追加到 `$OUT/<模式>.log`。训练目录还含 `experiment.json`、`training_inputs.json`、`selected/iter_*/train.parquet`、`timings.jsonl`、FSDP actor/optimizer 分片。独立 Oracle 的生成结果在 `$OUT/oracle/`，C 首轮共享 Oracle 在 `$OUT/runs/.initial_oracle/`，TensorBoard 在 `$OUT/tensorboard/{b,c}/`。续跑使用同路径同配置；新配置使用新 OUT。HF 全量导出需要在持久卷上预留模型权重空间，C 会写两份。

AMC23 留出题 40 道，step 0 和 step 1 各评每题一个贪心回答。B 每次仅评 full，C 每次评 full 和 retain_only。C 的全 chunk 是 1 道 retain-only / 6 道 both / 1 道 forget-only；实际一步只取 4 道。少量样本可能全对、全错或对齐分数打平；这些运行只用于验证接线。正式 pilot 沿用三份原 YAML 的 80 题、10 步、训练每题 16 个回答。

## 数据来源与 CPU 检查

`data/` 保存了两套固定版本数据集加工出的三份数据，每份含 Parquet、JSONL 和记录样本 ID 的 `pilot_source.json`。WebInstruct 数学 80 题来自 `TIGER-Lab/WebInstruct-verified-unfiltered@ac48a536b31d3cabb346e1139fb6c69ae631abd7`。AMC22 参考 16 题和 AMC23 留出 40 题来自 `AI-MO/aimo-validation-amc@69d78a4a2c840e82d69af6bc742bda09005f6316`。用仓库 `automated/prepare_graft_pilot.py`、seed 42 和 Qwen 模型的 tokenizer 准备。包内数据可以直接被 B/C 消费，规则判题在仓库 veRL 的 `math_reward.py`。

原生 Oracle 复用 Ray 路径的输入加载、聊天模板、规则判题和输出格式。通过 CLI 显式启用；两种后端的缓存独立。默认 Oracle 仍为 Ray Data。应用补丁后可在仓库根目录运行 CPU 回归。新用例使用模拟 vLLM，并在导入 Ray Data LLM 时令测试失败。四卡 PPU、真实生成、同步 LoRA 和分布式通信以实际 Docker 日志为准。

```bash
cd "$GA_REPO"
PYTHONPATH="$GA_REPO/verl${PYTHONPATH:+:$PYTHONPATH}" HF_HUB_OFFLINE=1 HF_DATASETS_OFFLINE=1 \
OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 TOKENIZERS_PARALLELISM=false \
python -m pytest -q tests/test_selection_baseline.py tests/test_graft_*.py \
  tests/test_ppu_native_oracle.py verl/tests/trainer/ppo/test_core_algos_on_cpu.py::test_grpo_and_vectorized_equivalence
```

两份上游数据集的数据卡均标注 Apache-2.0，随包许可证见 `DATA_LICENSE.txt`。保留的原始样本 ID 见各目录的 `pilot_source.json`，题目经抽样、格式转换和聊天模板长度筛选。[WebInstruct 数据卡](https://huggingface.co/datasets/TIGER-Lab/WebInstruct-verified-unfiltered/blob/ac48a536b31d3cabb346e1139fb6c69ae631abd7/README.md) · [AMC 数据卡](https://huggingface.co/datasets/AI-MO/aimo-validation-amc/blob/69d78a4a2c840e82d69af6bc742bda09005f6316/README.md)
